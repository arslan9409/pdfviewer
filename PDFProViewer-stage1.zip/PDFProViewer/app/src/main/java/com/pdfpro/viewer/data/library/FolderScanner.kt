package com.pdfpro.viewer.data.library

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class SavedFolder(val uri: String, val name: String)
data class ScannedFile(val uri: String, val name: String, val size: Long, val modified: Long)

/** Folders the user chose through the system folder picker (no storage permission needed). */
class FolderStore(context: Context) {
    private val prefs = context.getSharedPreferences("folders", Context.MODE_PRIVATE)

    fun load(): List<SavedFolder> = runCatching {
        val arr = JSONArray(prefs.getString("list", "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            SavedFolder(o.getString("uri"), o.optString("name", "Folder"))
        }
    }.getOrDefault(emptyList())

    fun save(list: List<SavedFolder>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name)) }
        prefs.edit().putString("list", arr.toString()).apply()
    }
}

object FolderScanner {
    private const val MAX_DEPTH = 4
    private const val MAX_FILES = 3000

    fun displayName(context: Context, tree: Uri): String = runCatching {
        val doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        context.contentResolver.query(
            doc, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null,
        )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull() ?: "Folder"

    /** Lists PDFs inside the chosen folder (and sub-folders, up to a sane depth). */
    suspend fun scan(context: Context, tree: Uri): List<ScannedFile> = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val out = ArrayList<ScannedFile>()
        val columns = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_SIZE,
        )

        fun walk(parentId: String, depth: Int) {
            if (out.size >= MAX_FILES) return
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
            val dirs = ArrayList<String>()
            runCatching {
                resolver.query(children, columns, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2) ?: ""
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            dirs.add(id)
                        } else if (mime == "application/pdf" || name.endsWith(".pdf", ignoreCase = true)) {
                            val docUri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                            out.add(ScannedFile(docUri.toString(), name, c.getLong(4), c.getLong(3)))
                        }
                    }
                }
            }
            if (depth < MAX_DEPTH) dirs.forEach { walk(it, depth + 1) }
        }

        runCatching { walk(DocumentsContract.getTreeDocumentId(tree), 0) }
        out
    }
}
