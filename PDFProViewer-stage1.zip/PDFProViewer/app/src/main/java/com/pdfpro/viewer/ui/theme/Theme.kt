package com.pdfpro.viewer.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.pdfpro.viewer.data.settings.ThemeMode

val LescoBlue = Color(0xFF0B5FA5)
val LescoBlueDark = Color(0xFF08437A)
val LescoGreen = Color(0xFF2E9B4B)
val LescoGreenDark = Color(0xFF1F7A3A)
val FavouriteGold = Color(0xFFF2A900)

private val LightColors = lightColorScheme(
    primary = LescoBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD9EAFB),
    onPrimaryContainer = Color(0xFF062B4F),
    secondary = LescoGreenDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDDF3E3),
    onSecondaryContainer = Color(0xFF0B3A1A),
    tertiary = Color(0xFF0F8F8A),
    background = Color.White,
    onBackground = Color(0xFF191C20),
    surface = Color.White,
    onSurface = Color(0xFF191C20),
    surfaceVariant = Color(0xFFE8EFF6),
    onSurfaceVariant = Color(0xFF3F4A56),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF5F8FC),
    surfaceContainer = Color(0xFFEFF4FA),
    surfaceContainerHigh = Color(0xFFE8EFF6),
    surfaceContainerHighest = Color(0xFFE1EAF2),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9CCBFF),
    onPrimary = Color(0xFF003258),
    primaryContainer = Color(0xFF00497D),
    onPrimaryContainer = Color(0xFFD0E4FF),
    secondary = Color(0xFF8FDDA0),
    onSecondary = Color(0xFF003918),
    secondaryContainer = Color(0xFF0B5A2A),
    onSecondaryContainer = Color(0xFFB1F1BF),
    tertiary = Color(0xFF72D9D3),
    background = Color(0xFF0E1318),
    onBackground = Color(0xFFE1E3E8),
    surface = Color(0xFF0E1318),
    onSurface = Color(0xFFE1E3E8),
    surfaceVariant = Color(0xFF232B33),
    onSurfaceVariant = Color(0xFFC0C7D0),
    surfaceContainerLowest = Color(0xFF0A0E12),
    surfaceContainerLow = Color(0xFF141A20),
    surfaceContainer = Color(0xFF182028),
    surfaceContainerHigh = Color(0xFF1F2831),
    surfaceContainerHighest = Color(0xFF27313B),
)

@Composable
fun PdfProTheme(mode: ThemeMode = ThemeMode.System, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Light -> false
        ThemeMode.Dark -> true
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = Typography(), // sp-based: follows the system font size
        content = content,
    )
}
