@file:OptIn(ExperimentalMaterial3Api::class)

package com.pdfpro.viewer.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdfpro.viewer.data.settings.AppSettings
import com.pdfpro.viewer.data.settings.FitMode
import com.pdfpro.viewer.data.settings.PageLayout
import com.pdfpro.viewer.data.settings.ThemeMode
import com.pdfpro.viewer.ui.common.StatusBarIcons

@Composable
fun SettingsScreen(onBack: () -> Unit, onClearRecent: () -> Unit) {
    StatusBarIcons(darkIcons = MaterialTheme.colorScheme.background.luminance() > 0.5f)
    val settings = AppSettings.get(LocalContext.current)
    val theme by settings.theme.collectAsStateWithLifecycle()
    val layout by settings.layout.collectAsStateWithLifecycle()
    val fit by settings.fit.collectAsStateWithLifecycle()
    val keepOn by settings.keepScreenOn.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Section("Appearance") {
                RadioRow("System default", theme == ThemeMode.System) { settings.setTheme(ThemeMode.System) }
                RadioRow("Light", theme == ThemeMode.Light) { settings.setTheme(ThemeMode.Light) }
                RadioRow("Dark", theme == ThemeMode.Dark) { settings.setTheme(ThemeMode.Dark) }
            }
            Section("Page layout") {
                RadioRow("Continuous scroll", layout == PageLayout.Continuous) { settings.setLayout(PageLayout.Continuous) }
                RadioRow("Single page", layout == PageLayout.Single) { settings.setLayout(PageLayout.Single) }
            }
            Section("Default zoom") {
                RadioRow("Fit to width", fit == FitMode.Width) { settings.setFit(FitMode.Width) }
                RadioRow("Fit whole page", fit == FitMode.Page) { settings.setFit(FitMode.Page) }
            }
            Section("Reading") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 56.dp)
                        .toggleable(value = keepOn, role = Role.Switch, onValueChange = { settings.setKeepScreenOn(it) })
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("Keep screen on while reading", Modifier.weight(1f))
                    Switch(checked = keepOn, onCheckedChange = null)
                }
            }
            Section("Privacy") {
                Text(
                    "Your reading history, bookmarks and favourites are stored only on this device. " +
                        "Nothing is uploaded and no analytics are collected.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(8.dp),
                )
                OutlinedButton(
                    onClick = { confirmClear = true },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                    shape = RoundedCornerShape(14.dp),
                ) { Text("Clear recent history") }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear recent history?") },
            text = { Text("The Recent list will be emptied. Your PDF files are not touched, and favourites and bookmarks are kept.") },
            confirmButton = {
                TextButton(onClick = { onClearRecent(); confirmClear = false }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(
                title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 8.dp, top = 4.dp, bottom = 4.dp),
            )
            content()
        }
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Text(label, modifier = Modifier.padding(start = 12.dp))
    }
}
