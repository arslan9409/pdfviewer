package com.pdfpro.viewer.ui.viewer

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import kotlin.math.roundToInt

const val MIN_SCALE = 1f
const val MAX_SCALE = 5f

/**
 * Zoom model for the continuous page list.
 *
 * - [scale] is the committed zoom: pages are laid out at `viewWidth * scale` wide, so scrolling
 *   stays natural and pages can be re-rendered sharply ([renderScale]).
 * - While a pinch or double-tap animation is running, a cheap GPU transform (layer*) is applied to
 *   the whole list. When the gesture ends, [commit] folds it into [scale]/[offsetX] and re-anchors
 *   the scroll position so the content under the fingers stays put.
 */
@Stable
class ZoomState {
    var scale by mutableFloatStateOf(1f)
        private set
    var renderScale by mutableFloatStateOf(1f)
        private set
    var offsetX by mutableFloatStateOf(0f)
        private set
    var layerScale by mutableFloatStateOf(1f)
        private set
    var layerTx by mutableFloatStateOf(0f)
        private set
    var layerTy by mutableFloatStateOf(0f)
        private set

    var viewWidth: Float = 0f
    private var focalY = 0f

    private fun maxOffset(forScale: Float) = ((forScale - 1f) * viewWidth / 2f).coerceAtLeast(0f)

    /** Horizontal pan while zoomed in (single finger). */
    fun panX(dx: Float) {
        val m = maxOffset(scale)
        offsetX = (offsetX + dx).coerceIn(-m, m)
    }

    /** Incremental pinch update; [centroid] is the current finger centre, [pan] its movement. */
    fun pinch(zoomChange: Float, centroid: Offset, pan: Offset) {
        val newLayer = (layerScale * zoomChange).coerceIn(MIN_SCALE / scale, MAX_SCALE / scale)
        val z = newLayer / layerScale
        val previous = centroid - pan
        layerTx = centroid.x + z * (layerTx - previous.x)
        layerTy = centroid.y + z * (layerTy - previous.y)
        layerScale = newLayer
        focalY = centroid.y
    }

    suspend fun animateTo(target: Float, focal: Offset, listState: LazyListState) {
        val ratio = target.coerceIn(MIN_SCALE, MAX_SCALE) / scale
        focalY = focal.y
        animate(1f, ratio, animationSpec = tween(240)) { v, _ ->
            layerScale = v
            layerTx = focal.x * (1f - v)
            layerTy = focal.y * (1f - v)
        }
        commit(listState)
    }

    suspend fun commit(listState: LazyListState) {
        if (layerScale == 1f && layerTx == 0f && layerTy == 0f) return
        val v = viewWidth
        val fy = focalY
        val ty = layerTy
        val tx = layerTx
        // Layout-space y of the point that currently sits under the focal point.
        val l = (fy - ty) / layerScale
        val anchor = listState.layoutInfo.visibleItemsInfo.minByOrNull {
            val top = it.offset.toFloat()
            val bottom = top + it.size
            when {
                l < top -> top - l
                l > bottom -> l - bottom
                else -> 0f
            }
        }

        val newScale = (scale * layerScale).coerceIn(MIN_SCALE, MAX_SCALE)
        val r = newScale / scale
        val newOffset = r * (v / 2f + offsetX) + tx - v / 2f

        scale = newScale
        renderScale = newScale
        val m = maxOffset(newScale)
        offsetX = newOffset.coerceIn(-m, m)
        layerScale = 1f
        layerTx = 0f
        layerTy = 0f

        if (anchor != null) {
            val t = ((l - anchor.offset) / anchor.size).coerceIn(0f, 1f)
            listState.scrollToItem(anchor.index, (t * anchor.size * r - fy).roundToInt())
        }
    }
}
