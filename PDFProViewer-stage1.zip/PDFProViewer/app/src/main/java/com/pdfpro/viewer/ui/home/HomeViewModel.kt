package com.pdfpro.viewer.ui.home

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pdfpro.viewer.data.library.FolderScanner
import com.pdfpro.viewer.data.library.FolderStore
import com.pdfpro.viewer.data.library.LibraryEntry
import com.pdfpro.viewer.data.library.LibraryRepository
import com.pdfpro.viewer.data.library.SavedFolder
import com.pdfpro.viewer.data.library.ScannedFile
import com.pdfpro.viewer.data.settings.AppSettings
import com.pdfpro.viewer.data.settings.SortKey
import com.pdfpro.viewer.data.settings.SortSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PdfItem(
    val uri: String,
    val name: String,
    val size: Long,
    val pages: Int?,
    val lastOpened: Long?,
    val modified: Long?,
    val favourite: Boolean,
)

data class FolderInfo(val uri: String, val name: String, val count: Int)

data class HomeData(
    val recent: List<PdfItem> = emptyList(),
    val favourites: List<PdfItem> = emptyList(),
    val all: List<PdfItem> = emptyList(),
    val folders: List<FolderInfo> = emptyList(),
    val folderItems: Map<String, List<PdfItem>> = emptyMap(),
)

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app
    private val library = LibraryRepository.get(app)
    val settings = AppSettings.get(app)
    private val folderStore = FolderStore(app)

    private val folders = MutableStateFlow(folderStore.load())
    private val scanned = MutableStateFlow<Map<String, List<ScannedFile>>>(emptyMap())
    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()
    private var scanJob: Job? = null

    val data: StateFlow<HomeData> =
        combine(library.entries, scanned, folders, _query, settings.sort) { entries, scan, fl, q, sort ->
            build(entries, scan, fl, q, sort)
        }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, HomeData())

    init {
        refreshFolders()
    }

    fun setQuery(q: String) { _query.value = q }

    fun setSort(key: SortKey) {
        val cur = settings.sort.value
        settings.setSort(
            if (cur.key == key) cur.copy(ascending = !cur.ascending)
            else SortSpec(key, ascending = key == SortKey.Name)
        )
    }

    fun toggleFavourite(item: PdfItem) {
        library.toggleFavourite(item.uri, item.name, item.size, item.pages ?: 0)
    }

    fun removeFromRecent(item: PdfItem) = library.removeFromRecent(item.uri)

    fun addFolder(uri: Uri) {
        viewModelScope.launch {
            val name = withContext(Dispatchers.IO) { FolderScanner.displayName(ctx, uri) }
            val current = folders.value
            if (current.none { it.uri == uri.toString() }) {
                val updated = current + SavedFolder(uri.toString(), name)
                folderStore.save(updated)
                folders.value = updated
            }
            refreshFolders()
        }
    }

    fun removeFolder(info: FolderInfo) {
        val updated = folders.value.filter { it.uri != info.uri }
        folderStore.save(updated)
        folders.value = updated
        runCatching {
            ctx.contentResolver.releasePersistableUriPermission(
                Uri.parse(info.uri), android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION,
            )
        }
        refreshFolders()
    }

    fun refreshFolders() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            _scanning.value = true
            val result = HashMap<String, List<ScannedFile>>()
            for (f in folders.value) result[f.uri] = FolderScanner.scan(ctx, Uri.parse(f.uri))
            scanned.value = result
            _scanning.value = false
        }
    }

    private fun LibraryEntry.toItem() = PdfItem(
        uri, name, size, pages.takeIf { it > 0 }, lastOpened.takeIf { it > 0 }, null, favourite,
    )

    private fun comparator(s: SortSpec): Comparator<PdfItem> {
        val base: Comparator<PdfItem> = when (s.key) {
            SortKey.Name -> compareBy<PdfItem> { it.name.lowercase() }
            SortKey.Date -> compareBy<PdfItem> { it.lastOpened ?: it.modified ?: 0L }
            SortKey.Size -> compareBy<PdfItem> { it.size }
        }
        return if (s.ascending) base else base.reversed()
    }

    private fun build(
        entries: List<LibraryEntry>,
        scan: Map<String, List<ScannedFile>>,
        fl: List<SavedFolder>,
        query: String,
        sort: SortSpec,
    ): HomeData {
        val q = query.trim()
        fun matches(i: PdfItem) = q.isEmpty() || i.name.contains(q, ignoreCase = true)
        val cmp = comparator(sort)
        val byUri = entries.associateBy { it.uri }

        val libItems = entries.map { it.toItem() }
        val rawFolderItems: Map<String, List<PdfItem>> = fl.associate { f ->
            f.uri to scan[f.uri].orEmpty().map { s ->
                val e = byUri[s.uri]
                PdfItem(
                    uri = s.uri,
                    name = e?.name ?: s.name,
                    size = if (s.size > 0) s.size else e?.size ?: 0L,
                    pages = e?.pages?.takeIf { it > 0 },
                    lastOpened = e?.lastOpened?.takeIf { it > 0 },
                    modified = s.modified.takeIf { it > 0 },
                    favourite = e?.favourite ?: false,
                )
            }
        }

        val everything = LinkedHashMap<String, PdfItem>()
        libItems.forEach { everything[it.uri] = it }
        rawFolderItems.values.flatten().forEach { everything[it.uri] = it }

        return HomeData(
            recent = libItems.filter { it.lastOpened != null && matches(it) }.sortedWith(cmp),
            favourites = everything.values.filter { it.favourite && matches(it) }.sortedWith(cmp),
            all = everything.values.filter(::matches).sortedWith(cmp),
            folders = fl.map { FolderInfo(it.uri, it.name, rawFolderItems[it.uri].orEmpty().size) },
            folderItems = rawFolderItems.mapValues { (_, list) -> list.filter(::matches).sortedWith(cmp) },
        )
    }
}
