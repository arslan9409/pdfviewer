package com.pdfpro.viewer.data.library

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One document the app knows about. [lastOpened] == 0 means "not in Recent". */
data class LibraryEntry(
    val uri: String,
    val name: String,
    val size: Long,
    val pages: Int,
    val lastOpened: Long,
    val favourite: Boolean = false,
    val lastPage: Int = 0,
    val bookmarks: List<Int> = emptyList(),
)

/**
 * Recents, favourites, bookmarks and reading positions. Stored as a small JSON file in the app's
 * private storage; nothing is uploaded anywhere. The original PDFs are never touched.
 */
class LibraryRepository private constructor(context: Context) {
    private val file = File(context.filesDir, "library.json")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var saveJob: Job? = null

    private val _entries = MutableStateFlow(load())
    val entries: StateFlow<List<LibraryEntry>> = _entries.asStateFlow()

    fun get(uri: String): LibraryEntry? = _entries.value.firstOrNull { it.uri == uri }

    fun recordOpened(uri: String, name: String, size: Long, pages: Int) = update { list ->
        val old = list.firstOrNull { it.uri == uri }
        val entry = LibraryEntry(
            uri, name, size, pages, System.currentTimeMillis(),
            old?.favourite ?: false, old?.lastPage ?: 0, old?.bookmarks ?: emptyList(),
        )
        (listOf(entry) + list.filter { it.uri != uri }).take(MAX_ENTRIES)
    }

    fun setLastPage(uri: String, page: Int) = update { list ->
        list.map { if (it.uri == uri) it.copy(lastPage = page) else it }
    }

    fun toggleFavourite(uri: String, name: String, size: Long, pages: Int) = update { list ->
        val old = list.firstOrNull { it.uri == uri }
        if (old == null) {
            listOf(LibraryEntry(uri, name, size, pages, 0L, favourite = true)) + list
        } else {
            list.map { if (it.uri == uri) it.copy(favourite = !it.favourite) else it }
        }
    }

    fun toggleBookmark(uri: String, page: Int) = update { list ->
        list.map {
            if (it.uri != uri) it
            else it.copy(bookmarks = if (page in it.bookmarks) it.bookmarks - page else (it.bookmarks + page).sorted())
        }
    }

    /** Takes a file out of Recent. Favourites and bookmarks are kept; otherwise the entry is dropped. */
    fun removeFromRecent(uri: String) = update { list -> list.mapNotNull { dropRecent(it, it.uri == uri) } }

    fun clearRecent() = update { list -> list.mapNotNull { dropRecent(it, true) } }

    fun rename(oldUri: String, newUri: String, newName: String) = update { list ->
        list.map { if (it.uri == oldUri) it.copy(uri = newUri, name = newName) else it }
    }

    fun remove(uri: String) = update { list -> list.filter { it.uri != uri } }

    private fun dropRecent(e: LibraryEntry, drop: Boolean): LibraryEntry? = when {
        !drop -> e
        e.favourite || e.bookmarks.isNotEmpty() -> e.copy(lastOpened = 0L)
        else -> null
    }

    private fun update(transform: (List<LibraryEntry>) -> List<LibraryEntry>) {
        _entries.update(transform)
        scheduleSave()
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(700)
            writeNow()
        }
    }

    private fun writeNow() {
        runCatching {
            val arr = JSONArray()
            _entries.value.forEach { e ->
                arr.put(
                    JSONObject()
                        .put("uri", e.uri).put("name", e.name).put("size", e.size)
                        .put("pages", e.pages).put("lastOpened", e.lastOpened)
                        .put("favourite", e.favourite).put("lastPage", e.lastPage)
                        .put("bookmarks", JSONArray(e.bookmarks))
                )
            }
            val tmp = File(file.parentFile, "library.json.tmp")
            tmp.writeText(arr.toString())
            tmp.renameTo(file)
        }
    }

    private fun load(): List<LibraryEntry> = runCatching {
        if (!file.exists()) return emptyList()
        val arr = JSONArray(file.readText())
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            val bm = o.optJSONArray("bookmarks")
            LibraryEntry(
                uri = o.getString("uri"),
                name = o.optString("name", "Document.pdf"),
                size = o.optLong("size"),
                pages = o.optInt("pages"),
                lastOpened = o.optLong("lastOpened"),
                favourite = o.optBoolean("favourite"),
                lastPage = o.optInt("lastPage"),
                bookmarks = if (bm == null) emptyList() else List(bm.length()) { bm.getInt(it) },
            )
        }
    }.getOrDefault(emptyList())

    companion object {
        private const val MAX_ENTRIES = 500
        @Volatile private var instance: LibraryRepository? = null
        fun get(context: Context): LibraryRepository =
            instance ?: synchronized(this) {
                instance ?: LibraryRepository(context.applicationContext).also { instance = it }
            }
    }
}
