package com.pdfpro.viewer.data.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileNotFoundException
import kotlin.math.roundToInt

/** Page size in PDF points (1/72 inch). Only the aspect ratio matters for layout. */
data class PageSize(val width: Int, val height: Int) {
    val aspect: Float get() = height.toFloat() / width.toFloat()
}

sealed class PdfOpenException(cause: Throwable? = null) : Exception(cause) {
    class PasswordProtected : PdfOpenException()
    class AccessDenied(cause: Throwable?) : PdfOpenException(cause)
    class NotFound(cause: Throwable? = null) : PdfOpenException(cause)
    class Corrupted(cause: Throwable? = null) : PdfOpenException(cause)
}

/**
 * Wraps Android's [PdfRenderer]. PdfRenderer allows only one open page at a time and is not
 * thread-safe, so every access is serialized through [lock].
 */
class PdfRendererSource private constructor(
    private val renderer: PdfRenderer,
    private val descriptor: ParcelFileDescriptor,
    val pageSizes: List<PageSize>,
) : AutoCloseable {

    private val lock = Any()
    @Volatile private var closed = false

    val pageCount: Int get() = pageSizes.size

    /** Size of the underlying file in bytes, or 0 if unknown. */
    val fileSize: Long get() = runCatching { descriptor.statSize }.getOrDefault(0L).coerceAtLeast(0L)

    /** Renders page [index] into a new bitmap [widthPx] wide (white background). */
    suspend fun render(index: Int, widthPx: Int): Bitmap = withContext(Dispatchers.IO) {
        synchronized(lock) {
            check(!closed) { "Document closed" }
            renderer.openPage(index).use { page ->
                val w = widthPx.coerceAtLeast(1)
                val h = (w * page.height.toFloat() / page.width).roundToInt().coerceAtLeast(1)
                val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bitmap
            }
        }
    }

    override fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            runCatching { renderer.close() }
            runCatching { descriptor.close() }
        }
    }

    companion object {
        suspend fun open(context: Context, uri: Uri): PdfRendererSource = withContext(Dispatchers.IO) {
            val resolver = context.contentResolver
            val pfd = try {
                resolver.openFileDescriptor(uri, "r") ?: throw PdfOpenException.NotFound()
            } catch (e: FileNotFoundException) {
                throw PdfOpenException.NotFound(e)
            } catch (e: SecurityException) {
                throw PdfOpenException.AccessDenied(e)
            }
            try {
                create(pfd)
            } catch (e: PdfOpenException.Corrupted) {
                // Some providers hand out non-seekable descriptors. Retry from a private cache copy.
                val copy = copyToCache(context, uri) ?: throw e
                val pfd2 = try {
                    ParcelFileDescriptor.open(copy, ParcelFileDescriptor.MODE_READ_ONLY)
                } catch (t: Exception) {
                    copy.delete()
                    throw e
                }
                copy.delete() // fd stays valid after unlink; file disappears when closed
                create(pfd2)
            }
        }

        /** Takes ownership of [pfd]; closes it on failure. */
        private fun create(pfd: ParcelFileDescriptor): PdfRendererSource {
            val renderer = try {
                PdfRenderer(pfd)
            } catch (e: SecurityException) {
                pfd.close()
                throw PdfOpenException.PasswordProtected()
            } catch (e: Exception) {
                pfd.close()
                throw PdfOpenException.Corrupted(e)
            }
            try {
                if (renderer.pageCount == 0) throw PdfOpenException.Corrupted()
                val sizes = (0 until renderer.pageCount).map { i ->
                    renderer.openPage(i).use { PageSize(it.width.coerceAtLeast(1), it.height.coerceAtLeast(1)) }
                }
                return PdfRendererSource(renderer, pfd, sizes)
            } catch (e: Exception) {
                runCatching { renderer.close() }
                runCatching { pfd.close() }
                throw e as? PdfOpenException ?: PdfOpenException.Corrupted(e)
            }
        }

        private fun copyToCache(context: Context, uri: Uri): File? = runCatching {
            val out = File(context.cacheDir, "open_${System.nanoTime()}.pdf")
            context.contentResolver.openInputStream(uri)?.use { input ->
                out.outputStream().use { input.copyTo(it) }
            } ?: return null
            out
        }.getOrNull()
    }
}

fun Context.queryDisplayName(uri: Uri): String? =
    runCatching {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment

fun Context.querySize(uri: Uri): Long =
    runCatching {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L
        }
    }.getOrNull() ?: 0L
