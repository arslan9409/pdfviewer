package com.pdfpro.viewer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.content.IntentCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdfpro.viewer.data.library.LibraryRepository
import com.pdfpro.viewer.data.settings.AppSettings
import com.pdfpro.viewer.ui.about.AboutScreen
import com.pdfpro.viewer.ui.home.HomeScreen
import com.pdfpro.viewer.ui.home.HomeViewModel
import com.pdfpro.viewer.ui.settings.SettingsScreen
import com.pdfpro.viewer.ui.theme.PdfProTheme
import com.pdfpro.viewer.ui.viewer.ViewerScreen
import com.pdfpro.viewer.ui.viewer.ViewerState
import com.pdfpro.viewer.ui.viewer.ViewerViewModel

private enum class Screen { Home, Settings, About }

/** File picker that also asks for a persistable read/write grant (needed for rename and delete). */
private class OpenPdfContract : ActivityResultContracts.OpenDocument() {
    override fun createIntent(context: Context, input: Array<String>): Intent =
        super.createIntent(context, input).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
}

class MainActivity : ComponentActivity() {

    private val viewerViewModel: ViewerViewModel by viewModels()
    private val homeViewModel: HomeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIntent(intent)

        val settings = AppSettings.get(this)

        setContent {
            val themeMode by settings.theme.collectAsStateWithLifecycle()
            PdfProTheme(themeMode) {
                val state by viewerViewModel.state.collectAsStateWithLifecycle()
                var screen by rememberSaveable { mutableStateOf(Screen.Home) }

                val picker = rememberLauncherForActivityResult(OpenPdfContract()) { uri ->
                    if (uri != null) {
                        keepAccess(uri, withWrite = true)
                        viewerViewModel.open(uri)
                    }
                }
                val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
                    if (uri != null) {
                        keepAccess(uri, withWrite = true)
                        homeViewModel.addFolder(uri)
                    }
                }
                val browse = { picker.launch(arrayOf("application/pdf")) }

                BackHandler(enabled = state !is ViewerState.Idle) { viewerViewModel.close() }
                BackHandler(enabled = state is ViewerState.Idle && screen != Screen.Home) { screen = Screen.Home }

                when {
                    state !is ViewerState.Idle -> ViewerScreen(
                        state = state,
                        viewModel = viewerViewModel,
                        onClose = viewerViewModel::close,
                        onOpenAnother = browse,
                    )
                    screen == Screen.Settings -> SettingsScreen(
                        onBack = { screen = Screen.Home },
                        onClearRecent = { LibraryRepository.get(this@MainActivity).clearRecent() },
                    )
                    screen == Screen.About -> AboutScreen(onBack = { screen = Screen.Home })
                    else -> HomeScreen(
                        viewModel = homeViewModel,
                        onOpen = { viewerViewModel.open(Uri.parse(it)) },
                        onBrowse = browse,
                        onAddFolder = { folderPicker.launch(null) },
                        onSettings = { screen = Screen.Settings },
                        onAbout = { screen = Screen.About },
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        homeViewModel.refreshFolders() // pick up files added or removed while the app was away
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun keepAccess(uri: Uri, withWrite: Boolean) {
        val read = Intent.FLAG_GRANT_READ_URI_PERMISSION
        val both = read or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try {
            contentResolver.takePersistableUriPermission(uri, if (withWrite) both else read)
        } catch (e: Exception) {
            runCatching { contentResolver.takePersistableUriPermission(uri, read) }
        }
    }

    private fun handleIntent(intent: Intent?) {
        val uri: Uri? = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
            else -> null
        }
        if (uri != null) viewerViewModel.open(uri)
    }
}
