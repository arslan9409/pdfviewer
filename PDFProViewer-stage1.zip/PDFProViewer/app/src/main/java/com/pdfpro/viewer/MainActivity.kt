package com.pdfpro.viewer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.content.IntentCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdfpro.viewer.ui.home.HomeScreen
import com.pdfpro.viewer.ui.theme.PdfProTheme
import com.pdfpro.viewer.ui.viewer.ViewerScreen
import com.pdfpro.viewer.ui.viewer.ViewerState
import com.pdfpro.viewer.ui.viewer.ViewerViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ViewerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIntent(intent)

        setContent {
            PdfProTheme {
                val state by viewModel.state.collectAsStateWithLifecycle()

                val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) {
                        runCatching {
                            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        viewModel.open(uri)
                    }
                }
                val browse = { picker.launch(arrayOf("application/pdf")) }

                BackHandler(enabled = state !is ViewerState.Idle) { viewModel.close() }

                when (state) {
                    ViewerState.Idle -> HomeScreen(onBrowse = browse)
                    else -> ViewerScreen(
                        state = state,
                        viewModel = viewModel,
                        onClose = viewModel::close,
                        onOpenAnother = browse,
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val uri: Uri? = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
            else -> null
        }
        if (uri != null) viewModel.open(uri)
    }
}
