package com.pdfpro.viewer.data.settings

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { System, Light, Dark }
enum class PageLayout { Continuous, Single }
enum class FitMode { Width, Page }
enum class SortKey(val label: String) { Name("Name"), Date("Date"), Size("Size") }

data class SortSpec(val key: SortKey = SortKey.Date, val ascending: Boolean = false)

/** Small SharedPreferences-backed settings store. Everything stays on the device. */
class AppSettings private constructor(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _theme = MutableStateFlow(readEnum("theme", ThemeMode.System))
    val theme: StateFlow<ThemeMode> = _theme.asStateFlow()

    private val _layout = MutableStateFlow(readEnum("layout", PageLayout.Continuous))
    val layout: StateFlow<PageLayout> = _layout.asStateFlow()

    private val _fit = MutableStateFlow(readEnum("fit", FitMode.Width))
    val fit: StateFlow<FitMode> = _fit.asStateFlow()

    private val _keepScreenOn = MutableStateFlow(prefs.getBoolean("keep_screen_on", false))
    val keepScreenOn: StateFlow<Boolean> = _keepScreenOn.asStateFlow()

    private val _gridView = MutableStateFlow(prefs.getBoolean("grid_view", false))
    val gridView: StateFlow<Boolean> = _gridView.asStateFlow()

    private val _sort = MutableStateFlow(
        SortSpec(readEnum("sort_key", SortKey.Date), prefs.getBoolean("sort_asc", false))
    )
    val sort: StateFlow<SortSpec> = _sort.asStateFlow()

    fun setTheme(v: ThemeMode) { _theme.value = v; prefs.edit().putString("theme", v.name).apply() }
    fun setLayout(v: PageLayout) { _layout.value = v; prefs.edit().putString("layout", v.name).apply() }
    fun setFit(v: FitMode) { _fit.value = v; prefs.edit().putString("fit", v.name).apply() }
    fun setKeepScreenOn(v: Boolean) { _keepScreenOn.value = v; prefs.edit().putBoolean("keep_screen_on", v).apply() }
    fun setGridView(v: Boolean) { _gridView.value = v; prefs.edit().putBoolean("grid_view", v).apply() }
    fun setSort(v: SortSpec) {
        _sort.value = v
        prefs.edit().putString("sort_key", v.key.name).putBoolean("sort_asc", v.ascending).apply()
    }

    private inline fun <reified T : Enum<T>> readEnum(key: String, default: T): T {
        val name = prefs.getString(key, null) ?: return default
        return enumValues<T>().firstOrNull { it.name == name } ?: default
    }

    companion object {
        @Volatile private var instance: AppSettings? = null
        fun get(context: Context): AppSettings =
            instance ?: synchronized(this) {
                instance ?: AppSettings(context.applicationContext).also { instance = it }
            }
    }
}
