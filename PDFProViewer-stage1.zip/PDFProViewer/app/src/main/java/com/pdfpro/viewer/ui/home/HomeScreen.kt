@file:OptIn(ExperimentalMaterial3Api::class)

package com.pdfpro.viewer.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.ViewAgenda
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdfpro.viewer.data.settings.SortKey
import com.pdfpro.viewer.ui.common.BrandGradient
import com.pdfpro.viewer.ui.common.PdfBadge
import com.pdfpro.viewer.ui.common.StatusBarIcons
import com.pdfpro.viewer.ui.common.formatDate
import com.pdfpro.viewer.ui.common.formatSize
import com.pdfpro.viewer.ui.theme.FavouriteGold

enum class HomeTab(val label: String, val icon: ImageVector) {
    Recent("Recent", Icons.Rounded.History),
    Favourites("Favourites", Icons.Rounded.Star),
    All("All PDFs", Icons.Rounded.PictureAsPdf),
    Folders("Folders", Icons.Rounded.Folder),
}

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpen: (String) -> Unit,
    onBrowse: () -> Unit,
    onAddFolder: () -> Unit,
    onSettings: () -> Unit,
    onAbout: () -> Unit,
) {
    StatusBarIcons(darkIcons = false) // the header gradient is dark

    val data by viewModel.data.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()
    val sort by viewModel.settings.sort.collectAsStateWithLifecycle()
    val grid by viewModel.settings.gridView.collectAsStateWithLifecycle()
    val scanning by viewModel.scanning.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableStateOf(HomeTab.Recent) }
    var openFolder by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingRemove by remember { mutableStateOf<PdfItem?>(null) }
    var pendingFolderRemove by remember { mutableStateOf<FolderInfo?>(null) }

    BackHandler(enabled = openFolder != null) { openFolder = null }

    val showingFolderList = tab == HomeTab.Folders && openFolder == null
    val items: List<PdfItem> = when (tab) {
        HomeTab.Recent -> data.recent
        HomeTab.Favourites -> data.favourites
        HomeTab.All -> data.all
        HomeTab.Folders -> openFolder?.let { data.folderItems[it].orEmpty() } ?: emptyList()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            NavigationBar {
                HomeTab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t; openFolder = null },
                        icon = { Icon(t.icon, contentDescription = null) },
                        label = { Text(t.label, maxLines = 1) },
                    )
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onBrowse,
                icon = { Icon(Icons.Rounded.FolderOpen, contentDescription = null) },
                text = { Text("Browse files") },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary,
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Header(onSettings = onSettings, onAbout = onAbout)

            OutlinedTextField(
                value = query,
                onValueChange = viewModel::setQuery,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                placeholder = { Text("Search PDFs") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setQuery("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
            )
            if (scanning) LinearProgressIndicator(Modifier.fillMaxWidth())

            if (!showingFolderList) {
                if (openFolder != null) {
                    val name = data.folders.firstOrNull { it.uri == openFolder }?.name ?: "Folder"
                    Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { openFolder = null }) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to folders")
                        }
                        Text(name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                ControlsRow(
                    count = items.size,
                    sortKey = sort.key,
                    ascending = sort.ascending,
                    grid = grid,
                    onSort = viewModel::setSort,
                    onToggleGrid = { viewModel.settings.setGridView(!grid) },
                )
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (showingFolderList) {
                    FolderList(
                        folders = data.folders,
                        onAddFolder = onAddFolder,
                        onOpen = { openFolder = it.uri },
                        onRemove = { pendingFolderRemove = it },
                    )
                } else if (items.isEmpty()) {
                    val searching = query.isNotBlank()
                    val (icon, title, message) = when {
                        searching -> Triple(Icons.Rounded.Search, "No results", "Nothing matches “${query.trim()}”.")
                        tab == HomeTab.Recent -> Triple(Icons.Rounded.History, "No recent documents", "PDFs you open will appear here.")
                        tab == HomeTab.Favourites -> Triple(Icons.Rounded.StarBorder, "No favourites yet", "Tap the star on any PDF to keep it here.")
                        tab == HomeTab.All -> Triple(
                            Icons.Rounded.PictureAsPdf, "No PDFs yet",
                            "Open a PDF, or add a folder in the Folders tab to list everything inside it.",
                        )
                        else -> Triple(Icons.Rounded.Folder, "No PDFs in this folder", "This folder doesn't contain any PDF files.")
                    }
                    EmptyState(
                        icon, title, message,
                        actionLabel = if (!searching && tab != HomeTab.Folders) "Browse files" else null,
                        onAction = onBrowse,
                    )
                } else if (grid) {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(160.dp),
                        contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(items, key = { it.uri }) { item ->
                            PdfGridCard(item, onClick = { onOpen(item.uri) }, onFavourite = { viewModel.toggleFavourite(item) })
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(items, key = { it.uri }) { item ->
                            PdfListCard(
                                item,
                                onClick = { onOpen(item.uri) },
                                onFavourite = { viewModel.toggleFavourite(item) },
                                onRemove = if (tab == HomeTab.Recent) ({ pendingRemove = item }) else null,
                            )
                        }
                    }
                }
            }
        }
    }

    pendingRemove?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingRemove = null },
            title = { Text("Remove from Recent?") },
            text = { Text("“${item.name}” will be removed from your recent list. The file itself is not deleted, and favourites and bookmarks are kept.") },
            confirmButton = {
                TextButton(onClick = { viewModel.removeFromRecent(item); pendingRemove = null }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { pendingRemove = null }) { Text("Cancel") } },
        )
    }
    pendingFolderRemove?.let { folder ->
        AlertDialog(
            onDismissRequest = { pendingFolderRemove = null },
            title = { Text("Remove folder?") },
            text = { Text("“${folder.name}” will no longer be listed in the app. Your files are not deleted.") },
            confirmButton = {
                TextButton(onClick = { viewModel.removeFolder(folder); pendingFolderRemove = null }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { pendingFolderRemove = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Header(onSettings: () -> Unit, onAbout: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Box(
        Modifier
            .fillMaxWidth()
            .background(BrandGradient)
            .statusBarsPadding()
            .padding(start = 20.dp, end = 8.dp, top = 14.dp, bottom = 18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PdfBadge(Modifier.size(48.dp).background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(14.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "LESCO PDF Viewer",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                )
                Text(
                    "Made by Arslan Mughal",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.85f),
                )
            }
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "More options", tint = Color.White)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Settings") },
                        leadingIcon = { Icon(Icons.Rounded.Settings, contentDescription = null) },
                        onClick = { menu = false; onSettings() },
                    )
                    DropdownMenuItem(
                        text = { Text("About") },
                        leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
                        onClick = { menu = false; onAbout() },
                    )
                }
            }
        }
    }
}

@Composable
private fun ControlsRow(
    count: Int,
    sortKey: SortKey,
    ascending: Boolean,
    grid: Boolean,
    onSort: (SortKey) -> Unit,
    onToggleGrid: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            if (count == 1) "1 PDF" else "$count PDFs",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        Box {
            AssistChip(
                onClick = { menu = true },
                label = { Text("Sort: ${sortKey.label} ${if (ascending) "↑" else "↓"}") },
                trailingIcon = { Icon(Icons.Rounded.ArrowDropDown, contentDescription = null) },
            )
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                SortKey.entries.forEach { k ->
                    DropdownMenuItem(
                        text = { Text(if (k == sortKey) "${k.label} ${if (ascending) "↑" else "↓"}" else k.label) },
                        onClick = { menu = false; onSort(k) },
                    )
                }
            }
        }
        IconButton(onClick = onToggleGrid) {
            Icon(
                if (grid) Icons.Rounded.ViewAgenda else Icons.Rounded.GridView,
                contentDescription = if (grid) "Switch to list view" else "Switch to grid view",
            )
        }
    }
}

private fun subtitle(item: PdfItem): String =
    listOfNotNull(
        item.size.takeIf { it > 0 }?.let(::formatSize),
        item.pages?.let { if (it == 1) "1 page" else "$it pages" },
        (item.lastOpened ?: item.modified)?.let(::formatDate),
    ).joinToString(" · ")

@Composable
private fun PdfListCard(item: PdfItem, onClick: () -> Unit, onFavourite: () -> Unit, onRemove: (() -> Unit)?) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            PdfBadge(Modifier.size(52.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                val sub = subtitle(item)
                if (sub.isNotEmpty()) {
                    Text(
                        sub, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            FavouriteButton(item.favourite, onFavourite)
            if (onRemove != null) {
                IconButton(onClick = onRemove) {
                    Icon(Icons.Rounded.Close, contentDescription = "Remove from recent list")
                }
            }
        }
    }
}

@Composable
private fun PdfGridCard(item: PdfItem, onClick: () -> Unit, onFavourite: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column {
            Box(
                Modifier.fillMaxWidth().heightIn(min = 96.dp).background(BrandGradient),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Rounded.PictureAsPdf, contentDescription = null, tint = Color.White,
                    modifier = Modifier.padding(vertical = 22.dp).size(44.dp),
                )
                Box(Modifier.align(Alignment.TopEnd)) {
                    FavouriteButton(item.favourite, onFavourite, onGradient = true)
                }
            }
            Column(Modifier.padding(12.dp)) {
                Text(item.name, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                val sub = subtitle(item)
                if (sub.isNotEmpty()) {
                    Text(
                        sub, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

@Composable
private fun FavouriteButton(favourite: Boolean, onClick: () -> Unit, onGradient: Boolean = false) {
    IconButton(onClick = onClick) {
        Icon(
            if (favourite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
            contentDescription = if (favourite) "Remove from favourites" else "Add to favourites",
            tint = when {
                favourite -> FavouriteGold
                onGradient -> Color.White
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            },
        )
    }
}

@Composable
private fun FolderList(
    folders: List<FolderInfo>,
    onAddFolder: () -> Unit,
    onOpen: (FolderInfo) -> Unit,
    onRemove: (FolderInfo) -> Unit,
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            OutlinedButton(
                onClick = onAddFolder,
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                shape = RoundedCornerShape(16.dp),
            ) {
                Icon(Icons.Rounded.CreateNewFolder, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Add folder")
            }
        }
        if (folders.isEmpty()) {
            item {
                EmptyState(
                    Icons.Rounded.Folder, "No folders added",
                    "Add a folder (for example Downloads or Documents) and every PDF inside it will be listed here and in All PDFs.",
                    actionLabel = null, onAction = {},
                )
            }
        }
        items(folders, key = { it.uri }) { f ->
            Card(
                onClick = { onOpen(f) },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.secondaryContainer),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (f.count == 1) "1 PDF" else "${f.count} PDFs",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { onRemove(f) }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Remove folder ${f.name}")
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(
    icon: ImageVector,
    title: String,
    message: String,
    actionLabel: String?,
    onAction: () -> Unit,
) {
    Column(
        Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.size(80.dp).clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.size(16.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.size(6.dp))
        Text(
            message, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (actionLabel != null) {
            Spacer(Modifier.size(20.dp))
            Button(onClick = onAction, modifier = Modifier.heightIn(min = 48.dp)) { Text(actionLabel) }
        }
    }
}
