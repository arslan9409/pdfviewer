package com.pdfpro.viewer.ui.viewer

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.pdfpro.viewer.data.pdf.PageSize
import com.pdfpro.viewer.data.pdf.PdfOpenException
import com.pdfpro.viewer.data.pdf.PdfRendererSource
import com.pdfpro.viewer.data.pdf.queryDisplayName
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ViewerError { PasswordProtected, AccessDenied, NotFound, Corrupted, Unknown }

sealed interface ViewerState {
    data object Idle : ViewerState
    data object Loading : ViewerState
    data class Ready(val name: String, val pageSizes: List<PageSize>) : ViewerState
    data class Failed(val error: ViewerError) : ViewerState
}

class ViewerViewModel(
    app: Application,
    private val saved: SavedStateHandle,
) : AndroidViewModel(app) {

    private val _state = MutableStateFlow<ViewerState>(ViewerState.Idle)
    val state: StateFlow<ViewerState> = _state.asStateFlow()

    private var source: PdfRendererSource? = null
    private var job: Job? = null
    private var currentUri: Uri? = saved.get<String>(KEY_URI)?.let(Uri::parse)

    /** Page to show first when the document opens (survives rotation and process death). */
    val restoredPage: Int get() = saved.get<Int>(KEY_PAGE) ?: 0

    private val cache = object : LruCache<Long, Bitmap>((Runtime.getRuntime().maxMemory() / 6).toInt()) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }

    init {
        currentUri?.let { open(it) } // restore after process death
    }

    fun open(uri: Uri) {
        val s = _state.value
        if (uri == currentUri && s !is ViewerState.Idle && s !is ViewerState.Failed) return
        job?.cancel()
        if (uri != currentUri) saved[KEY_PAGE] = 0
        currentUri = uri
        saved[KEY_URI] = uri.toString()
        releaseSource()
        _state.value = ViewerState.Loading

        val ctx = getApplication<Application>()
        job = viewModelScope.launch {
            try {
                val name = withContext(Dispatchers.IO) { ctx.queryDisplayName(uri) } ?: "Document.pdf"
                val opened = PdfRendererSource.open(ctx, uri)
                source = opened
                _state.value = ViewerState.Ready(name, opened.pageSizes)
            } catch (e: CancellationException) {
                throw e
            } catch (e: PdfOpenException) {
                _state.value = ViewerState.Failed(
                    when (e) {
                        is PdfOpenException.PasswordProtected -> ViewerError.PasswordProtected
                        is PdfOpenException.AccessDenied -> ViewerError.AccessDenied
                        is PdfOpenException.NotFound -> ViewerError.NotFound
                        is PdfOpenException.Corrupted -> ViewerError.Corrupted
                    }
                )
            } catch (e: Exception) {
                _state.value = ViewerState.Failed(ViewerError.Unknown)
            }
        }
    }

    fun close() {
        job?.cancel()
        releaseSource()
        currentUri = null
        saved.remove<String>(KEY_URI)
        saved.remove<Int>(KEY_PAGE)
        _state.value = ViewerState.Idle
    }

    fun setPage(index: Int) {
        saved[KEY_PAGE] = index
    }

    /** Returns a cached or freshly rendered bitmap for the page, or null if no document is open. */
    suspend fun renderPage(index: Int, widthPx: Int): Bitmap? {
        val key = (index.toLong() shl 32) or widthPx.toLong()
        cache.get(key)?.let { return it }
        val src = source ?: return null
        val bitmap = src.render(index, widthPx)
        cache.put(key, bitmap)
        return bitmap
    }

    private fun releaseSource() {
        cache.evictAll()
        source?.close()
        source = null
    }

    override fun onCleared() {
        releaseSource()
    }

    private companion object {
        const val KEY_URI = "uri"
        const val KEY_PAGE = "page"
    }
}
