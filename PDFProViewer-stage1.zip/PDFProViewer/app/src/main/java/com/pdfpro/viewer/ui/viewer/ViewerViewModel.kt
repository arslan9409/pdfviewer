package com.pdfpro.viewer.ui.viewer

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.provider.DocumentsContract
import android.util.LruCache
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.pdfpro.viewer.data.library.LibraryRepository
import com.pdfpro.viewer.data.pdf.PageSize
import com.pdfpro.viewer.data.pdf.PdfOpenException
import com.pdfpro.viewer.data.pdf.PdfRendererSource
import com.pdfpro.viewer.data.pdf.querySize
import com.pdfpro.viewer.data.pdf.queryDisplayName
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class ViewerError { PasswordProtected, AccessDenied, NotFound, Corrupted, Unknown }

sealed interface ViewerState {
    data object Idle : ViewerState
    data object Loading : ViewerState
    data class Ready(val name: String, val pageSizes: List<PageSize>) : ViewerState
    data class Failed(val error: ViewerError) : ViewerState
}

data class DocDetails(
    val name: String,
    val size: Long,
    val pages: Int,
    val pageWidthPt: Int?,
    val pageHeightPt: Int?,
    val lastOpened: Long?,
)

class ViewerViewModel(
    app: Application,
    private val saved: SavedStateHandle,
) : AndroidViewModel(app) {

    private val library = LibraryRepository.get(app)

    private val _state = MutableStateFlow<ViewerState>(ViewerState.Idle)
    val state: StateFlow<ViewerState> = _state.asStateFlow()

    private var source: PdfRendererSource? = null
    private var job: Job? = null
    private var currentUri: Uri? = saved.get<String>(KEY_URI)?.let(Uri::parse)
    private val currentKey = MutableStateFlow(currentUri?.toString())

    /** Page to show first when the document opens (saved position, survives restarts). */
    var initialPage: Int = 0
        private set

    val uri: Uri? get() = currentUri

    val bookmarks: StateFlow<List<Int>> = combine(library.entries, currentKey) { list, key ->
        list.firstOrNull { it.uri == key }?.bookmarks ?: emptyList()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val cache = object : LruCache<Long, Bitmap>((Runtime.getRuntime().maxMemory() / 6).toInt()) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }

    init {
        currentUri?.let { open(it) } // restore after process death
    }

    fun open(uri: Uri) {
        val s = _state.value
        if (uri == currentUri && s !is ViewerState.Idle && s !is ViewerState.Failed) return
        job?.cancel()
        if (uri != currentUri) saved.remove<Int>(KEY_PAGE)
        currentUri = uri
        currentKey.value = uri.toString()
        saved[KEY_URI] = uri.toString()
        releaseSource()
        _state.value = ViewerState.Loading

        val ctx = getApplication<Application>()
        job = viewModelScope.launch {
            try {
                val (name, size) = withContext(Dispatchers.IO) { ctx.queryDisplayName(uri) to ctx.querySize(uri) }
                val opened = PdfRendererSource.open(ctx, uri)
                source = opened
                val displayName = name ?: "Document.pdf"
                val key = uri.toString()
                val entry = library.get(key)
                initialPage = (saved.get<Int>(KEY_PAGE) ?: entry?.lastPage ?: 0)
                    .coerceIn(0, opened.pageCount - 1)
                library.recordOpened(key, displayName, if (size > 0) size else opened.fileSize, opened.pageCount)
                _state.value = ViewerState.Ready(displayName, opened.pageSizes)
            } catch (e: CancellationException) {
                throw e
            } catch (e: PdfOpenException) {
                _state.value = ViewerState.Failed(
                    when (e) {
                        is PdfOpenException.PasswordProtected -> ViewerError.PasswordProtected
                        is PdfOpenException.AccessDenied -> ViewerError.AccessDenied
                        is PdfOpenException.NotFound -> ViewerError.NotFound
                        is PdfOpenException.Corrupted -> ViewerError.Corrupted
                    }
                )
            } catch (e: Exception) {
                _state.value = ViewerState.Failed(ViewerError.Unknown)
            }
        }
    }

    fun close() {
        job?.cancel()
        releaseSource()
        currentUri = null
        currentKey.value = null
        saved.remove<String>(KEY_URI)
        saved.remove<Int>(KEY_PAGE)
        _state.value = ViewerState.Idle
    }

    fun setPage(index: Int) {
        saved[KEY_PAGE] = index
        currentUri?.let { library.setLastPage(it.toString(), index) }
    }

    fun toggleBookmark(page: Int) {
        currentUri?.let { library.toggleBookmark(it.toString(), page) }
    }

    fun details(): DocDetails? {
        val s = _state.value as? ViewerState.Ready ?: return null
        val entry = currentUri?.toString()?.let { library.get(it) }
        val first = s.pageSizes.firstOrNull()
        return DocDetails(
            s.name, entry?.size ?: 0L, s.pageSizes.size,
            first?.width, first?.height, entry?.lastOpened?.takeIf { it > 0 },
        )
    }

    /** Returns a cached or freshly rendered bitmap for the page, or null if no document is open. */
    suspend fun renderPage(index: Int, widthPx: Int): Bitmap? {
        val key = (index.toLong() shl 32) or widthPx.toLong()
        cache.get(key)?.let { return it }
        val src = source ?: return null
        val bitmap = src.render(index, widthPx)
        cache.put(key, bitmap)
        return bitmap
    }

    /**
     * Copies the open PDF into the app cache and returns a secure content:// Uri (FileProvider)
     * that share targets such as WhatsApp, Gmail or Drive can read.
     */
    suspend fun prepareShare(displayName: String): Uri? {
        val src = currentUri ?: return null
        val ctx = getApplication<Application>()
        return withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(ctx.cacheDir, "shared").apply {
                    mkdirs()
                    listFiles()?.forEach { it.delete() }
                }
                val safe = displayName.replace(Regex("[^\\p{L}\\p{N} ._-]"), "_").ifBlank { "document" }
                val fileName = if (safe.endsWith(".pdf", ignoreCase = true)) safe else "$safe.pdf"
                val out = File(dir, fileName)
                ctx.contentResolver.openInputStream(src)?.use { input ->
                    out.outputStream().use { input.copyTo(it) }
                } ?: return@runCatching null
                FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", out)
            }.getOrNull()
        }
    }

    /** Writes a copy of the open PDF to a location the user picked. */
    suspend fun saveCopy(dest: Uri): Boolean {
        val src = currentUri ?: return false
        val ctx = getApplication<Application>()
        return withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(src)!!.use { input ->
                    ctx.contentResolver.openOutputStream(dest, "w")!!.use { output -> input.copyTo(output) }
                }
                true
            }.getOrDefault(false)
        }
    }

    /** Renames the file on disk. Only works if the file provider allows it (needs write access). */
    suspend fun rename(newName: String): Boolean {
        val old = currentUri ?: return false
        val ctx = getApplication<Application>()
        val wanted = if (newName.endsWith(".pdf", ignoreCase = true)) newName else "$newName.pdf"
        return withContext(Dispatchers.IO) {
            val renamed = runCatching {
                DocumentsContract.renameDocument(ctx.contentResolver, old, wanted)
            }.getOrNull() ?: return@withContext false
            val finalName = ctx.queryDisplayName(renamed) ?: wanted
            currentUri = renamed
            currentKey.value = renamed.toString()
            saved[KEY_URI] = renamed.toString()
            library.rename(old.toString(), renamed.toString(), finalName)
            _state.update { if (it is ViewerState.Ready) it.copy(name = finalName) else it }
            true
        }
    }

    /** Deletes the file from the device. The caller must have asked the user to confirm first. */
    suspend fun deleteFile(): Boolean {
        val target = currentUri ?: return false
        val ctx = getApplication<Application>()
        val ok = withContext(Dispatchers.IO) {
            runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, target) }.getOrDefault(false)
        }
        if (ok) {
            library.remove(target.toString())
            close()
        }
        return ok
    }

    private fun releaseSource() {
        cache.evictAll()
        source?.close()
        source = null
    }

    override fun onCleared() {
        releaseSource()
    }

    private companion object {
        const val KEY_URI = "uri"
        const val KEY_PAGE = "page"
    }
}
