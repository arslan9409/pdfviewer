@file:OptIn(ExperimentalMaterial3Api::class)

package com.pdfpro.viewer.ui.viewer

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import com.pdfpro.viewer.data.pdf.PageSize
import com.pdfpro.viewer.ui.common.formatDate
import com.pdfpro.viewer.ui.common.formatSize
import kotlinx.coroutines.CancellationException
import java.util.Locale
import kotlin.math.roundToInt

private const val MAX_RENDER_WIDTH = 2400
private const val MAX_RENDER_HEIGHT = 4096
private const val THUMB_WIDTH = 240

@Composable
internal fun PdfPage(
    index: Int,
    size: PageSize,
    pageCount: Int,
    viewWidth: Int,
    zoom: ZoomState,
    viewModel: ViewerViewModel,
) {
    val maxWidth = minOf(MAX_RENDER_WIDTH, (MAX_RENDER_HEIGHT / size.aspect).toInt()).coerceAtLeast(1)
    val renderWidth = (viewWidth * zoom.renderScale).roundToInt().coerceIn(1, maxWidth)
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Keeps showing the previous (lower-resolution) bitmap until the sharper one is ready.
    LaunchedEffect(index, renderWidth) {
        try {
            viewModel.renderPage(index, renderWidth)?.let { bitmap = it }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Document closed or render failed: leave whatever is on screen.
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .layout { measurable, constraints ->
                val w = (constraints.maxWidth * zoom.scale).roundToInt().coerceAtLeast(1)
                val h = (w * size.aspect).roundToInt().coerceAtLeast(1)
                val itemHeight = if (zoom.singleMode) maxOf(h, zoom.viewHeight.roundToInt()) else h
                val placeable = measurable.measure(Constraints.fixed(w, h))
                layout(constraints.maxWidth, itemHeight) {
                    placeable.place(
                        ((constraints.maxWidth - w) / 2f + zoom.offsetX).roundToInt(),
                        (itemHeight - h) / 2,
                    )
                }
            }
            .background(Color.White),
        contentAlignment = Alignment.Center,
    ) {
        val current = bitmap
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = "Page ${index + 1} of $pageCount",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
internal fun PagePill(current: Int, total: Int, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        shadowElevation = 2.dp,
    ) {
        Row(
            Modifier
                .heightIn(min = 44.dp)
                .clickable(onClickLabel = "Go to page", onClick = onClick)
                .semantics { contentDescription = "Page $current of $total" }
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("$current / $total", style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
internal fun JumpToPageDialog(
    pageCount: Int,
    current: Int,
    onDismiss: () -> Unit,
    onJump: (Int) -> Unit,
) {
    var text by rememberSaveable { mutableStateOf((current + 1).toString()) }
    val page = text.toIntOrNull()
    val valid = page != null && page in 1..pageCount

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Go to page") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter(Char::isDigit).take(6) },
                label = { Text("Page (1–$pageCount)") },
                singleLine = true,
                isError = !valid,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { if (valid && page != null) onJump(page) }),
            )
        },
        confirmButton = {
            TextButton(onClick = { if (valid && page != null) onJump(page) }, enabled = valid) { Text("Go") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
internal fun DetailsDialog(details: DocDetails, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Document details") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DetailRow("Name", details.name)
                DetailRow("Size", if (details.size > 0) formatSize(details.size) else "Unknown")
                DetailRow("Pages", details.pages.toString())
                if (details.pageWidthPt != null && details.pageHeightPt != null) {
                    DetailRow(
                        "Page size",
                        String.format(
                            Locale.getDefault(), "%.0f × %.0f mm",
                            details.pageWidthPt * 25.4 / 72.0, details.pageHeightPt * 25.4 / 72.0,
                        ),
                    )
                }
                details.lastOpened?.let { DetailRow("Last opened", formatDate(it)) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
internal fun RenameDialog(currentName: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by rememberSaveable { mutableStateOf(currentName.removeSuffix(".pdf")) }
    val valid = text.isNotBlank() && text.none { it == '/' || it == '\\' }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename file") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("File name") },
                suffix = { Text(".pdf") },
                singleLine = true,
                isError = !valid,
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(text.trim()) }, enabled = valid) { Text("Rename") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
internal fun DeleteDialog(name: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Delete this file?") },
        text = { Text("“$name” will be permanently deleted from your device. This can't be undone.") },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text("Delete", color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Bottom sheet with a page-thumbnail grid and the list of bookmarks. */
@Composable
internal fun PagesSheet(
    initialTab: Int,
    pageSizes: List<PageSize>,
    current: Int,
    bookmarks: List<Int>,
    viewModel: ViewerViewModel,
    onGo: (Int) -> Unit,
    onRemoveBookmark: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var tab by remember { mutableIntStateOf(initialTab) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.8f)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Pages") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Bookmarks (${bookmarks.size})") })
            }
            if (tab == 0) {
                val gridState = rememberLazyGridState(initialFirstVisibleItemIndex = current)
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(96.dp),
                    state = gridState,
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    items(pageSizes.size) { i ->
                        PageThumb(i, pageSizes[i], i == current, viewModel) { onGo(i) }
                    }
                }
            } else if (bookmarks.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "No bookmarks yet. Tap the bookmark icon at the top while reading to save a page.",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(bookmarks.sorted(), key = { it }) { p ->
                        ListItem(
                            headlineContent = { Text("Page ${p + 1}") },
                            trailingContent = {
                                IconButton(onClick = { onRemoveBookmark(p) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Remove bookmark for page ${p + 1}")
                                }
                            },
                            modifier = Modifier.clickable { onGo(p) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PageThumb(
    index: Int,
    size: PageSize,
    selected: Boolean,
    viewModel: ViewerViewModel,
    onClick: () -> Unit,
) {
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(index) {
        bitmap = try {
            viewModel.renderPage(index, THUMB_WIDTH)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }
    val borderColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClickLabel = "Go to page ${index + 1}", onClick = onClick),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f / size.aspect)
                .background(Color.White)
                .border(if (selected) 3.dp else 1.dp, borderColor),
        ) {
            bitmap?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = "Page ${index + 1} thumbnail",
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        Text("${index + 1}", style = MaterialTheme.typography.labelMedium)
    }
}
