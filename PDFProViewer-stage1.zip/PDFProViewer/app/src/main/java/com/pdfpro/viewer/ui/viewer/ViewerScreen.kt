package com.pdfpro.viewer.ui.viewer

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import com.pdfpro.viewer.data.pdf.PageSize
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private const val MAX_RENDER_WIDTH = 2400
private const val MAX_RENDER_HEIGHT = 4096

@Composable
fun ViewerScreen(
    state: ViewerState,
    viewModel: ViewerViewModel,
    onClose: () -> Unit,
    onOpenAnother: () -> Unit,
) {
    when (state) {
        is ViewerState.Ready -> PdfReader(state, viewModel, onClose)
        ViewerState.Loading -> CenteredScaffold(onClose) {
            CircularProgressIndicator()
            Spacer(Modifier.height(20.dp))
            Text("Opening document…", style = MaterialTheme.typography.bodyLarge)
        }
        is ViewerState.Failed -> {
            val (title, message) = errorText(state.error)
            CenteredScaffold(onClose) {
                Icon(
                    Icons.Rounded.ErrorOutline, contentDescription = null,
                    modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.error,
                )
                Spacer(Modifier.height(16.dp))
                Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text(
                    message, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(24.dp))
                Button(onClick = onOpenAnother, modifier = Modifier.heightIn(min = 48.dp)) {
                    Text("Choose another PDF")
                }
            }
        }
        ViewerState.Idle -> Unit
    }
}

private fun errorText(error: ViewerError): Pair<String, String> = when (error) {
    ViewerError.PasswordProtected ->
        "Password-protected PDF" to "This file is encrypted. Opening password-protected PDFs isn't supported in this version yet."
    ViewerError.AccessDenied ->
        "Can't access this file" to "The app doesn't have permission to read it. Try selecting it again with Browse files."
    ViewerError.NotFound ->
        "File not found" to "The file may have been moved or deleted."
    ViewerError.Corrupted ->
        "Can't open this PDF" to "The file looks damaged or isn't a valid PDF."
    ViewerError.Unknown ->
        "Something went wrong" to "An unexpected error occurred while opening the file."
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CenteredScaffold(onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = {}, navigationIcon = { BackButton(onClose) }) },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            content = content,
        )
    }
}

@Composable
private fun BackButton(onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Close document")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PdfReader(state: ViewerState.Ready, viewModel: ViewerViewModel, onClose: () -> Unit) {
    val pageCount = state.pageSizes.size
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = viewModel.restoredPage.coerceIn(0, pageCount - 1),
    )
    val zoom = remember { ZoomState() }
    val scope = rememberCoroutineScope()
    var showJump by rememberSaveable { mutableStateOf(false) }

    // The page under the vertical centre of the viewport is the "current" page.
    val currentPage by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val centre = (info.viewportStartOffset + info.viewportEndOffset) / 2
            info.visibleItemsInfo.firstOrNull { centre >= it.offset && centre <= it.offset + it.size }?.index
                ?: listState.firstVisibleItemIndex
        }
    }
    LaunchedEffect(currentPage) { viewModel.setPage(currentPage) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant)) {
        TopAppBar(
            title = { Text(state.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = { BackButton(onClose) },
        )

        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clipToBounds()
                // Pinch (two fingers) and horizontal pan when zoomed. Runs in the Initial pass so a
                // pinch is consumed before the list can treat it as a scroll.
                .pointerInput(zoom) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        var pinched = false
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val pressed = event.changes.count { it.pressed }
                            if (pressed >= 2) {
                                val z = event.calculateZoom()
                                val pan = event.calculatePan()
                                if (z != 1f || pan != Offset.Zero) {
                                    pinched = true
                                    zoom.pinch(z, event.calculateCentroid(useCurrent = true), pan)
                                }
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                            } else if (pinched) {
                                event.changes.forEach { it.consume() }
                            } else if (pressed == 1 && zoom.scale > 1f) {
                                zoom.panX(event.calculatePan().x) // vertical drag is left to the list
                            }
                        } while (event.changes.any { it.pressed })
                        if (pinched) scope.launch { zoom.commit(listState) }
                    }
                }
                .pointerInput(zoom) {
                    detectTapGestures(onDoubleTap = { p ->
                        scope.launch { zoom.animateTo(if (zoom.scale > 1.05f) 1f else 2.5f, p, listState) }
                    })
                },
        ) {
            val viewWidth = constraints.maxWidth
            zoom.viewWidth = viewWidth.toFloat()

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        transformOrigin = TransformOrigin(0f, 0f)
                        scaleX = zoom.layerScale
                        scaleY = zoom.layerScale
                        translationX = zoom.layerTx
                        translationY = zoom.layerTy
                    },
                contentPadding = PaddingValues(bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(pageCount, key = { it }) { index ->
                    PdfPage(index, state.pageSizes[index], pageCount, viewWidth, zoom, viewModel)
                }
            }

            PagePill(
                current = currentPage + 1,
                total = pageCount,
                onClick = { showJump = true },
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp),
            )
        }
    }

    if (showJump) {
        JumpToPageDialog(
            pageCount = pageCount,
            current = currentPage,
            onDismiss = { showJump = false },
            onJump = { page ->
                showJump = false
                scope.launch { listState.scrollToItem(page - 1) }
            },
        )
    }
}

@Composable
private fun PdfPage(
    index: Int,
    size: PageSize,
    pageCount: Int,
    viewWidth: Int,
    zoom: ZoomState,
    viewModel: ViewerViewModel,
) {
    val maxWidth = minOf(MAX_RENDER_WIDTH, (MAX_RENDER_HEIGHT / size.aspect).toInt()).coerceAtLeast(1)
    val renderWidth = (viewWidth * zoom.renderScale).roundToInt().coerceIn(1, maxWidth)
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Keeps showing the previous (lower-resolution) bitmap until the sharper one is ready.
    LaunchedEffect(index, renderWidth) {
        try {
            viewModel.renderPage(index, renderWidth)?.let { bitmap = it }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Document closed or render failed: leave whatever is on screen.
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .layout { measurable, constraints ->
                val w = (constraints.maxWidth * zoom.scale).roundToInt()
                val h = (w * size.aspect).roundToInt()
                val placeable = measurable.measure(Constraints.fixed(w, h))
                layout(constraints.maxWidth, h) {
                    placeable.place(((constraints.maxWidth - w) / 2f + zoom.offsetX).roundToInt(), 0)
                }
            }
            .background(Color.White),
        contentAlignment = Alignment.Center,
    ) {
        val current = bitmap
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = "Page ${index + 1} of $pageCount",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun PagePill(current: Int, total: Int, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        shadowElevation = 4.dp,
    ) {
        Row(
            Modifier
                .heightIn(min = 48.dp)
                .clickable(onClickLabel = "Go to page", onClick = onClick)
                .semantics { contentDescription = "Page $current of $total" }
                .padding(horizontal = 24.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("$current / $total", style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun JumpToPageDialog(
    pageCount: Int,
    current: Int,
    onDismiss: () -> Unit,
    onJump: (Int) -> Unit,
) {
    var text by rememberSaveable { mutableStateOf((current + 1).toString()) }
    val page = text.toIntOrNull()
    val valid = page != null && page in 1..pageCount

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Go to page") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter(Char::isDigit).take(6) },
                label = { Text("Page (1–$pageCount)") },
                singleLine = true,
                isError = !valid,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { if (valid && page != null) onJump(page) }),
            )
        },
        confirmButton = {
            TextButton(onClick = { if (valid && page != null) onJump(page) }, enabled = valid) { Text("Go") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
