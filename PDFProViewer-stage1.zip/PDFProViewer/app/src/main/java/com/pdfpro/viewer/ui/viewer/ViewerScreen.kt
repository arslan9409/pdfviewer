@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.pdfpro.viewer.ui.viewer

import android.content.ClipData
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.FitScreen
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.ViewAgenda
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material.icons.rounded.CropPortrait
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdfpro.viewer.data.settings.AppSettings
import com.pdfpro.viewer.data.settings.FitMode
import com.pdfpro.viewer.data.settings.PageLayout
import com.pdfpro.viewer.ui.common.StatusBarIcons
import com.pdfpro.viewer.ui.common.findActivity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun ViewerScreen(
    state: ViewerState,
    viewModel: ViewerViewModel,
    onClose: () -> Unit,
    onOpenAnother: () -> Unit,
) {
    StatusBarIcons(darkIcons = MaterialTheme.colorScheme.background.luminance() > 0.5f)
    when (state) {
        is ViewerState.Ready -> PdfReader(state, viewModel, onClose)
        ViewerState.Loading -> CenteredScaffold(onClose) {
            CircularProgressIndicator()
            Spacer(Modifier.height(20.dp))
            Text("Opening document…", style = MaterialTheme.typography.bodyLarge)
        }
        is ViewerState.Failed -> {
            val (title, message) = errorText(state.error)
            CenteredScaffold(onClose) {
                Icon(
                    Icons.Rounded.ErrorOutline, contentDescription = null,
                    modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.error,
                )
                Spacer(Modifier.height(16.dp))
                Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text(
                    message, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(24.dp))
                Button(onClick = onOpenAnother, modifier = Modifier.heightIn(min = 48.dp)) {
                    Text("Choose another PDF")
                }
            }
        }
        ViewerState.Idle -> Unit
    }
}

private fun errorText(error: ViewerError): Pair<String, String> = when (error) {
    ViewerError.PasswordProtected ->
        "Password-protected PDF" to "This file is encrypted. Opening password-protected PDFs isn't supported in this version yet."
    ViewerError.AccessDenied ->
        "Can't access this file" to "The app doesn't have permission to read it. Try selecting it again with Browse files."
    ViewerError.NotFound ->
        "File not found" to "The file may have been moved or deleted."
    ViewerError.Corrupted ->
        "Can't open this PDF" to "The file looks damaged or isn't a valid PDF."
    ViewerError.Unknown ->
        "Something went wrong" to "An unexpected error occurred while opening the file."
}

@Composable
private fun CenteredScaffold(onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = {}, navigationIcon = { BackButton(onClose) }) },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            content = content,
        )
    }
}

@Composable
private fun BackButton(onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Close document")
    }
}

private class MenuEntry(val label: String, val icon: ImageVector, val onClick: () -> Unit)

@Composable
private fun PdfReader(state: ViewerState.Ready, viewModel: ViewerViewModel, onClose: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    val activity = remember(context) { context.findActivity() }
    val settings = remember { AppSettings.get(context) }
    val keepOn by settings.keepScreenOn.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()

    val pageCount = state.pageSizes.size
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = viewModel.initialPage.coerceIn(0, pageCount - 1),
    )
    val zoom = remember { ZoomState() }
    val scope = rememberCoroutineScope()

    var single by rememberSaveable { mutableStateOf(settings.layout.value == PageLayout.Single) }
    var immersive by rememberSaveable { mutableStateOf(false) }
    var sheet by rememberSaveable { mutableStateOf(0) } // 0 = closed, 1 = pages, 2 = bookmarks
    var showJump by rememberSaveable { mutableStateOf(false) }
    var showDetails by rememberSaveable { mutableStateOf(false) }
    var showRename by rememberSaveable { mutableStateOf(false) }
    var showDelete by rememberSaveable { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    SideEffect { zoom.singleMode = single }

    // The page under the vertical centre of the viewport is the "current" page.
    val currentPage by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val centre = (info.viewportStartOffset + info.viewportEndOffset) / 2
            info.visibleItemsInfo.firstOrNull { centre >= it.offset && centre <= it.offset + it.size }?.index
                ?: listState.firstVisibleItemIndex
        }
    }
    LaunchedEffect(currentPage) { viewModel.setPage(currentPage) }

    // Optional default: open fitted to the whole page.
    LaunchedEffect(Unit) {
        if (settings.fit.value == FitMode.Page) {
            snapshotFlow { zoom.viewHeight }.first { it > 0f }
            val s = zoom.fitPageScale(state.pageSizes[currentPage].aspect)
            zoom.setInitialScale(s)
        }
    }

    // Keep screen on (setting) and always restore the orientation lock when leaving.
    DisposableEffect(keepOn) {
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }
    DisposableEffect(Unit) {
        onDispose { activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    }
    DisposableEffect(immersive) {
        val controller = activity?.window?.let { WindowCompat.getInsetsController(it, view) }
        if (immersive) {
            controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    fun toast(text: String) = Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
    fun centre() = Offset(zoom.viewWidth / 2f, zoom.viewHeight / 2f)

    fun goToPage(page: Int) {
        scope.launch { listState.animateScrollToItem(page.coerceIn(0, pageCount - 1)) }
    }
    fun zoomBy(factor: Float) {
        scope.launch { zoom.animateTo(zoom.scale * factor, centre(), listState) }
    }
    fun fitWidth() {
        scope.launch { zoom.animateTo(1f, centre(), listState) }
    }
    fun fitPage() {
        scope.launch { zoom.animateTo(zoom.fitPageScale(state.pageSizes[currentPage].aspect), centre(), listState) }
    }
    fun toggleLayout() {
        val page = currentPage
        single = !single
        settings.setLayout(if (single) PageLayout.Single else PageLayout.Continuous)
        scope.launch { listState.scrollToItem(page) }
    }
    fun rotate() {
        val landscape = context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        activity?.requestedOrientation =
            if (landscape) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }
    fun share() {
        scope.launch {
            val shareUri = viewModel.prepareShare(state.name)
            if (shareUri == null) {
                toast("Couldn't prepare the file for sharing")
            } else {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, shareUri)
                    clipData = ClipData.newRawUri(state.name, shareUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(send, "Share PDF"))
            }
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { dest ->
        if (dest != null) {
            scope.launch { toast(if (viewModel.saveCopy(dest)) "Copy saved" else "Couldn't save the copy") }
        }
    }

    val bookmarked = currentPage in bookmarks
    val entries = listOf(
        MenuEntry("Page thumbnails", Icons.Rounded.GridView) { sheet = 1 },
        MenuEntry("Bookmarks", Icons.Rounded.Bookmarks) { sheet = 2 },
        MenuEntry("Go to page", Icons.Rounded.Tag) { showJump = true },
        MenuEntry(if (single) "Continuous scroll" else "Single page mode", if (single) Icons.Rounded.ViewAgenda else Icons.Rounded.CropPortrait) { toggleLayout() },
        MenuEntry("Fit to width", Icons.Rounded.FitScreen) { fitWidth() },
        MenuEntry("Fit to page", Icons.Rounded.FitScreen) { fitPage() },
        MenuEntry("Rotate screen", Icons.Rounded.ScreenRotation) { rotate() },
        MenuEntry("Fullscreen", Icons.Rounded.Fullscreen) { immersive = true; toast("Tap the page to exit fullscreen") },
    )
    val fileEntries = listOf(
        MenuEntry("Print", Icons.Rounded.Print) {
            viewModel.uri?.let { PdfPrinter.print(context, it, state.name) }
        },
        MenuEntry("Save a copy", Icons.Rounded.SaveAlt) { saveLauncher.launch(state.name) },
        MenuEntry("Document details", Icons.Rounded.Info) { showDetails = true },
        MenuEntry("Rename", Icons.Rounded.DriveFileRenameOutline) { showRename = true },
        MenuEntry("Delete", Icons.Rounded.Delete) { showDelete = true },
    )

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant)) {
        AnimatedVisibility(visible = !immersive) {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                title = {
                    Column {
                        Text(
                            state.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Text(
                            "LESCO PDF Viewer", maxLines = 1,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                },
                navigationIcon = { BackButton(onClose) },
                actions = {
                    IconButton(onClick = { share() }) {
                        Icon(Icons.Rounded.Share, contentDescription = "Share PDF")
                    }
                    IconButton(onClick = { viewModel.toggleBookmark(currentPage) }) {
                        Icon(
                            if (bookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                            contentDescription = if (bookmarked) "Remove bookmark from this page" else "Bookmark this page",
                            tint = if (bookmarked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = "More options")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            entries.forEach { e ->
                                DropdownMenuItem(
                                    text = { Text(e.label) },
                                    leadingIcon = { Icon(e.icon, contentDescription = null) },
                                    onClick = { menuOpen = false; e.onClick() },
                                )
                            }
                            HorizontalDivider()
                            fileEntries.forEach { e ->
                                DropdownMenuItem(
                                    text = { Text(e.label) },
                                    leadingIcon = { Icon(e.icon, contentDescription = null) },
                                    onClick = { menuOpen = false; e.onClick() },
                                )
                            }
                        }
                    }
                },
            )
        }

        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clipToBounds()
                // Pinch (two fingers) and horizontal pan when zoomed. Runs in the Initial pass so a
                // pinch is consumed before the list can treat it as a scroll.
                .pointerInput(zoom) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        var pinched = false
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val pressed = event.changes.count { it.pressed }
                            if (pressed >= 2) {
                                val z = event.calculateZoom()
                                val pan = event.calculatePan()
                                if (z != 1f || pan != Offset.Zero) {
                                    pinched = true
                                    zoom.pinch(z, event.calculateCentroid(useCurrent = true), pan)
                                }
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                            } else if (pinched) {
                                event.changes.forEach { it.consume() }
                            } else if (pressed == 1 && zoom.scale > 1f) {
                                zoom.panX(event.calculatePan().x) // vertical drag is left to the list
                            }
                        } while (event.changes.any { it.pressed })
                        if (pinched) scope.launch { zoom.commit(listState) }
                    }
                }
                .pointerInput(zoom) {
                    detectTapGestures(
                        onTap = { if (immersive) immersive = false },
                        onDoubleTap = { p ->
                            val target = if (zoom.scale > 1.05f || zoom.scale < 0.95f) 1f else 2.5f
                            scope.launch { zoom.animateTo(target, p, listState) }
                        },
                    )
                },
        ) {
            val viewWidth = constraints.maxWidth
            zoom.viewWidth = viewWidth.toFloat()
            zoom.viewHeight = constraints.maxHeight.toFloat()

            val snap = rememberSnapFlingBehavior(listState)
            val free = ScrollableDefaults.flingBehavior()

            LazyColumn(
                state = listState,
                flingBehavior = if (single && zoom.scale <= 1.01f) snap else free,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        transformOrigin = TransformOrigin(0f, 0f)
                        scaleX = zoom.layerScale
                        scaleY = zoom.layerScale
                        translationX = zoom.layerTx
                        translationY = zoom.layerTy
                    },
                contentPadding = PaddingValues(bottom = if (single) 0.dp else 8.dp),
                verticalArrangement = Arrangement.spacedBy(if (single) 0.dp else 8.dp),
            ) {
                items(pageCount, key = { it }) { index ->
                    PdfPage(index, state.pageSizes[index], pageCount, viewWidth, zoom, viewModel)
                }
            }

            if (immersive) {
                PagePill(
                    current = currentPage + 1,
                    total = pageCount,
                    onClick = { showJump = true },
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp),
                )
            }
        }

        AnimatedVisibility(visible = !immersive) {
            Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 6.dp) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { goToPage(currentPage - 1) }, enabled = currentPage > 0) {
                        Icon(Icons.Rounded.KeyboardArrowUp, contentDescription = "Previous page")
                    }
                    PagePill(currentPage + 1, pageCount, onClick = { showJump = true })
                    IconButton(onClick = { goToPage(currentPage + 1) }, enabled = currentPage < pageCount - 1) {
                        Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Next page")
                    }
                    IconButton(onClick = { zoomBy(1f / 1.4f) }) {
                        Icon(Icons.Rounded.ZoomOut, contentDescription = "Zoom out")
                    }
                    IconButton(onClick = { zoomBy(1.4f) }) {
                        Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom in")
                    }
                    val atFitWidth = zoom.scale in 0.98f..1.02f
                    IconButton(onClick = { if (atFitWidth) fitPage() else fitWidth() }) {
                        Icon(
                            Icons.Rounded.FitScreen,
                            contentDescription = if (atFitWidth) "Fit whole page" else "Fit to width",
                        )
                    }
                }
            }
        }
    }

    if (showJump) {
        JumpToPageDialog(
            pageCount = pageCount,
            current = currentPage,
            onDismiss = { showJump = false },
            onJump = { page ->
                showJump = false
                goToPage(page - 1)
            },
        )
    }
    if (sheet != 0) {
        PagesSheet(
            initialTab = sheet - 1,
            pageSizes = state.pageSizes,
            current = currentPage,
            bookmarks = bookmarks,
            viewModel = viewModel,
            onGo = { page ->
                sheet = 0
                scope.launch { listState.scrollToItem(page) }
            },
            onRemoveBookmark = { viewModel.toggleBookmark(it) },
            onDismiss = { sheet = 0 },
        )
    }
    val details = if (showDetails) viewModel.details() else null
    if (details != null) {
        DetailsDialog(details, onDismiss = { showDetails = false })
    }
    if (showRename) {
        RenameDialog(
            currentName = state.name,
            onDismiss = { showRename = false },
            onConfirm = { newName ->
                showRename = false
                scope.launch {
                    if (viewModel.rename(newName)) toast("Renamed")
                    else toast("Couldn't rename. The file may be read-only or was opened from another app.")
                }
            },
        )
    }
    if (showDelete) {
        DeleteDialog(
            name = state.name,
            onDismiss = { showDelete = false },
            onConfirm = {
                showDelete = false
                scope.launch {
                    if (!viewModel.deleteFile()) {
                        toast("Couldn't delete. The file may be read-only or was opened from another app.")
                    }
                }
            },
        )
    }
}
