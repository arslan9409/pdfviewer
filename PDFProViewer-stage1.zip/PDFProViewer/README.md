# LESCO PDF Viewer (v0.2.0) - Made by Arslan Mughal

Kotlin, Jetpack Compose, Material 3, Android PdfRenderer. Package: com.pdfpro.viewer, minSdk 26, targetSdk 35.

## Build
Upload the zip to GitHub (same file name replaces the old one). GitHub Actions builds the APK:
Actions tab > latest run > Artifacts > PDFProViewer-debug-apk.
Local: `gradle wrapper --gradle-version 8.9` then `./gradlew assembleDebug`
APK path: app/build/outputs/apk/debug/app-debug.apk

The project now ships a fixed debug keystore (app/debug.keystore), so future APKs install over this one.
(Uninstall the older build once; it was signed with a different temporary key.)

## Implemented (written, not yet device-tested)
Home: Recent, Favourites, All PDFs, Folders tabs; search; sort by name/date/size; list/grid; add/remove folders
(system folder picker, no storage permission); remove from Recent; About; Settings (theme, default layout,
default zoom, keep screen on, clear history); splash screen; light/dark LESCO-inspired theme.
Viewer: back, filename, share (FileProvider), bookmarks, prev/next, page pill + jump, zoom in/out,
pinch and double-tap zoom, fit width / fit page, continuous and single-page modes, thumbnails sheet,
bookmarks list, fullscreen, rotate, print, save a copy, document details, rename and delete (with
confirmation, only where the file provider allows), last-page restore, opening PDFs from other apps.

## Not yet implemented (needs a PDFium engine - next stage)
Text search + highlights, text selection/copy, password-protected PDFs, table of contents.
