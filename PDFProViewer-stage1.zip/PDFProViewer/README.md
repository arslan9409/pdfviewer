# PDF Pro Viewer — Stage 1 (core reading)

Kotlin · Jetpack Compose · Material 3 · Android `PdfRenderer` · minSdk 26 · targetSdk 35

## Build (needs Android Studio or JDK 17 + Android SDK 35)
**Android Studio:** File > Open > select this folder, wait for Gradle sync, then Run (or Build > Build APK(s)).

**Command line:**
```
gradle wrapper --gradle-version 8.9     # once; the wrapper .jar isn't included
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`
Install: `adb install -r app/build/outputs/apk/debug/app-debug.apk`

## Stage 1 includes
- Browse files (system picker, no permissions) and "Open with" / "Share to" from other apps
- Continuous vertical scroll, pinch zoom (1x-5x), double-tap zoom, sharp re-render after zoom
- Page indicator, tap it to jump to a page
- Reading position kept across rotation and process death (not yet across app restarts: Stage 2)
- Loading state and clear errors for corrupt / unreadable / missing / password-protected files
- Light/dark follows system

## Known gaps (planned)
- Password-protected PDFs show a clear message only; unlocking needs PDFium (Stage 3)
- No recents, bookmarks, search, TOC, text selection, share/print/rename, settings yet
- Strings are hardcoded (moved to resources in the polish stage)
- Not compiled or run by the author: expect to fix small issues on first build

## APK without a computer (GitHub Actions)
1. Create a GitHub repo, upload all files of this folder (including the hidden `.github` folder).
2. Open the Actions tab > "Build debug APK" > Run workflow.
3. When it finishes, download the artifact `PDFProViewer-debug-apk` (a zip containing app-debug.apk).
